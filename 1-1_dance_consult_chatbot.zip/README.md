To deploy this assistant:
1. Upload to Vercel
2. Add your .env key
3. Connect frontend to Vercel URL.